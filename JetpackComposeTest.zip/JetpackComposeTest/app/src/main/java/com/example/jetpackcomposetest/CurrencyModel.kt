package com.example.jetpackcomposetest

import android.os.Parcelable
import androidx.annotation.Keep
import kotlinx.parcelize.Parcelize

@Keep
@Parcelize
data class CurrencyModel(
    val currencyCode: String = "MMK",
    val currencyName: String = CurrencyNames.MMK,
    val flagEmoji: String = Flags.MMK,
    val exchangeRate: String = "1"
) : Parcelable

@Keep
data class LatestRates(
    val info: String = "Central Bank of Myanmar",
    val description: String = "Official Website of Central Bank of Myanmar",
    val timestamp: String = "1640764800",
    val rates: Rates = Rates()
)

@Keep
data class Rates(
    val USD: String = "1,778.0",
    val NZD: String = "1,208.4",
    val LKR: String = "8.7802",
    val CZK: String = "80.624",
    val JPY: String = "1,546.4",
    val VND: String = "7.7897",
    val PHP: String = "34.808",
    val KRW: String = "149.75",
    val BRL: String = "315.88",
    val HKD: String = "228.05",
    val RSD: String = "17.067",
    val MYR: String = "425.00",
    val CAD: String = "1,387.1",
    val GBP: String = "2,384.9",
    val NOK: String = "201.56",
    val ILS: String = "572.17",
    val SEK: String = "195.98",
    val DKK: String = "269.89",
    val AUD: String = "1,285.8",
    val RUB: String = "24.143",
    val KWD: String = "5,872.8",
    val INR: String = "23.773",
    val BND: String = "1,312.7",
    val EUR: String = "2,006.7",
    val ZAR: String = "112.94",
    val NPR: String = "14.858",
    val CNY: String = "279.15",
    val CHF: String = "1,935.8",
    val THB: String = "53.043",
    val PKR: String = "9.9570",
    val KES: String = "15.714",
    val EGP: String = "112.89",
    val BDT: String = "20.724",
    val SAR: String = "473.50",
    val LAK: String = "15.915",
    val IDR: String = "12.475",
    val KHR: String = "43.664",
    val SGD: String = "1,312.7"
) {
    val currencyModelsList = listOf(
        CurrencyModel("USD", CurrencyNames.USD, Flags.USD, USD.removeComma),
        CurrencyModel("NZD", CurrencyNames.NZD, Flags.NZD, NZD.removeComma),
        CurrencyModel("LKR", CurrencyNames.LKR, Flags.LKR, LKR.removeComma),
        CurrencyModel("CZK", CurrencyNames.CZK, Flags.CZK, CZK),
        CurrencyModel("JPY", CurrencyNames.JPY, Flags.JPY, JPY),
        CurrencyModel("VND", CurrencyNames.VND, Flags.VND, VND),
        CurrencyModel("PHP", CurrencyNames.PHP, Flags.PHP, PHP),
        CurrencyModel("KRW", CurrencyNames.KRW, Flags.KRW, KRW),
        CurrencyModel("BRL", CurrencyNames.BRL, Flags.BRL, BRL),
        CurrencyModel("HKD", CurrencyNames.HKD, Flags.HKD, HKD),
        CurrencyModel("RSD", CurrencyNames.RSD, Flags.RSD, RSD),
        CurrencyModel("MYR", CurrencyNames.MYR, Flags.MYR, MYR),
        CurrencyModel("CAD", CurrencyNames.CAD, Flags.CAD, CAD),
        CurrencyModel("GBP", CurrencyNames.GBP, Flags.GBP, GBP),
        CurrencyModel("NOK", CurrencyNames.NOK, Flags.NOK, NOK),
        CurrencyModel("ILS", CurrencyNames.ILS, Flags.ILS, ILS),
        CurrencyModel("SEK", CurrencyNames.SEK, Flags.SEK, SEK),
        CurrencyModel("DKK", CurrencyNames.DKK, Flags.DKK, DKK),
        CurrencyModel("AUD", CurrencyNames.AUD, Flags.AUD, AUD),
        CurrencyModel("RUB", CurrencyNames.RUB, Flags.RUB, RUB),
        CurrencyModel("KWD", CurrencyNames.KWD, Flags.KWD, KWD),
        CurrencyModel("INR", CurrencyNames.INR, Flags.INR, INR),
        CurrencyModel("BND", CurrencyNames.BND, Flags.BND, BND),
        CurrencyModel("EUR", CurrencyNames.EUR, Flags.EUR, EUR),
        CurrencyModel("ZAR", CurrencyNames.ZAR, Flags.ZAR, ZAR),
        CurrencyModel("NPR", CurrencyNames.NPR, Flags.NPR, NPR),
        CurrencyModel("CNY", CurrencyNames.CNY, Flags.CNY, CNY),
        CurrencyModel("CHF", CurrencyNames.CHF, Flags.CHF, CHF),
        CurrencyModel("THB", CurrencyNames.THB, Flags.THB, THB),
        CurrencyModel("PKR", CurrencyNames.PKR, Flags.PKR, PKR),
        CurrencyModel("KES", CurrencyNames.KES, Flags.KES, KES),
        CurrencyModel("EGP", CurrencyNames.EGP, Flags.EGP, EGP),
        CurrencyModel("BDT", CurrencyNames.BDT, Flags.BDT, BDT),
        CurrencyModel("SAR", CurrencyNames.SAR, Flags.SAR, SAR),
        CurrencyModel("LAK", CurrencyNames.LAK, Flags.LAK, LAK),
        CurrencyModel("IDR", CurrencyNames.IDR, Flags.IDR, IDR),
        CurrencyModel("KHR", CurrencyNames.KHR, Flags.KHR, KHR),
        CurrencyModel("SGD", CurrencyNames.SGD, Flags.SGD, SGD)
    )
}

val String.removeComma get() = replace(",", "")