package com.example.jetpackcomposetest

object CurrencyNames {
    const val AUD = "Australian Dollar"
    const val BDT = "Bangladesh Taka"
    const val BND = "Brunei Dollar"
    const val BRL = "Brazilian Real"
    const val CAD = "Canadian Dollar"
    const val CHF = "Swiss Franc"
    const val CNY = "Chinese Yuan"
    const val CZK = "Czech Koruna"
    const val DKK = "Danish Krone"
    const val EGP = "Egyptian Pound"
    const val EUR = "Euro"
    const val GBP = "Pound Sterling"
    const val HKD = "Hong Kong Dollar"
    const val IDR = "Indonesian Rupiah"
    const val ILS = "Israeli Shekel"
    const val INR = "Indian Rupee"
    const val JPY = "Japanese Yen"
    const val KES = "Kenya Shilling"
    const val KHR = "Cambodian Riel"
    const val KRW = "Korean Won"
    const val KWD = "Kuwaiti Dinar"
    const val LAK = "Lao Kip"
    const val LKR = "Sri Lankan Rupee"
    const val MMK = "Myanmar Kyat"
    const val MYR = "Malaysian Ringgit"
    const val NOK = "Norwegian Kroner"
    const val NPR = "Nepalese Rupee"
    const val NZD = "New Zealand Dollar"
    const val PHP = "Philippines Peso"
    const val PKR = "Pakistani Rupee"
    const val RSD = "Serbian Dinar"
    const val RUB = "Russian Rouble"
    const val SAR = "Saudi Arabian Riyal"
    const val SEK = "Swedish Krona"
    const val SGD = "Singapore Dollar"
    const val THB = "Thai Baht"
    const val USD = "United State Dollar"
    const val VND = "Vietnamese Dong"
    const val ZAR = "South Africa Rand"

    val list = listOf(
        AUD, BDT, BND, BRL, CAD, CHF, CNY, CZK, DKK, EGP, EUR, GBP, HKD, IDR, ILS, INR,
        JPY, KES, KHR, KRW, KWD, LAK, LKR, MMK, MYR, NOK, NPR, NZD, PHP, PKR, RSD, RUB, SAR, SEK,
        SGD, THB, USD, VND, ZAR
    )
}