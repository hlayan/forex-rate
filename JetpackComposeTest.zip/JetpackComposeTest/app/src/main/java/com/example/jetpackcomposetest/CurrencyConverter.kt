package com.example.jetpackcomposetest

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.OutlinedTextField
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@OptIn(ExperimentalComposeUiApi::class)
@Composable
fun CurrencyConverter(
    currencyModel: CurrencyModel,
    otherRate: MutableState<String>,
    mmkRate: MutableState<String>
) {
    Column(
        verticalArrangement = Arrangement.spacedBy(16.dp),
        modifier = Modifier.padding(16.dp)
    ) {

        ConverterField(
            text = otherRate.value,
            labelText = currencyModel.run { "$currencyCode $flagEmoji" }
        ) { text ->
            otherRate.value = text
            val test = kotlin.runCatching {
                val double = text.toDouble()
                val exchangeRate = currencyModel.exchangeRate.replace(",", "").toDouble()
                (double * exchangeRate).toString()
            }
            mmkRate.value = test.getOrDefault("")
        }

        ConverterField(
            text = mmkRate.value,
            placeholderText = currencyModel.exchangeRate
        ) { text ->
            mmkRate.value = text
            try {
                val double = text.toDouble()
                val exchangeRate = currencyModel.exchangeRate.replace(",", "").toDouble()
                otherRate.value = (double / exchangeRate).toString()
            } catch (e: NumberFormatException) {
                otherRate.value = ""
            }
        }
    }
}

@OptIn(ExperimentalComposeUiApi::class)
@Composable
fun ConverterField(
    text: String,
    labelText: String = "MMK ${Flags.MMK}",
    placeholderText: String = "1",
    onValueChange: (String) -> Unit
) {
    val focusManager = LocalFocusManager.current
    val keyboardController = LocalSoftwareKeyboardController.current
    OutlinedTextField(
        value = text,
        onValueChange = onValueChange,
        label = {
            Text(
                text = labelText,
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp
            )
        },
        placeholder = {
            Text(
                text = placeholderText,
                textAlign = TextAlign.Right,
                fontSize = 18.sp,
                modifier = Modifier.fillMaxWidth()
            )
        },
        singleLine = true,
        modifier = Modifier.fillMaxWidth(),
        shape = CutCornerShape(8.dp),
        textStyle = TextStyle(textAlign = TextAlign.Right, fontSize = 18.sp, color = Color.Black),
        keyboardOptions = KeyboardOptions(
            imeAction = ImeAction.Done,
            keyboardType = KeyboardType.Number
        ),
        keyboardActions = KeyboardActions(
            onDone = {
                keyboardController?.hide()
                focusManager.clearFocus()
            }
        )
    )
}

@Preview(showBackground = true)
@Composable
fun CurrencyConverterPreview() {
    val otherRate = remember { mutableStateOf("1") }
    val mmkRate = remember { mutableStateOf("1778.0") }
    CurrencyConverter(CurrencyModel(), otherRate = otherRate, mmkRate = mmkRate)
}