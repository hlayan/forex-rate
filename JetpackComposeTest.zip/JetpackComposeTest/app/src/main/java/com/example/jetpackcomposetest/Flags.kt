package com.example.jetpackcomposetest

object Flags {
    const val AUD = "\ud83c\udde6\ud83c\uddfa"
    const val BDT = "\ud83c\udde7\ud83c\udde9"
    const val BND = "\ud83c\udde7\ud83c\uddf3"
    const val BRL = "\ud83c\udde7\ud83c\uddf7"
    const val CAD = "\ud83c\udde8\ud83c\udde6"
    const val CHF = "\ud83c\uddeb\ud83c\uddf7"
    const val CNY = "\ud83c\udde8\ud83c\uddf3"
    const val CZK = "\ud83c\udde8\ud83c\uddff"
    const val DKK = "\ud83c\udde9\ud83c\uddf0"
    const val EGP = "\ud83c\uddea\ud83c\uddec"
    const val EUR = "\ud83c\uddea\ud83c\uddfa"
    const val GBP = "\ud83c\uddec\ud83c\udde7"
    const val HKD = "\ud83c\udded\ud83c\uddf0"
    const val IDR = "\ud83c\uddee\ud83c\udde9"
    const val ILS = "\ud83c\uddee\ud83c\uddf1"
    const val INR = "\ud83c\uddee\ud83c\uddf3"
    const val JPY = "\ud83c\uddef\ud83c\uddf5"
    const val KES = "\ud83c\uddf0\ud83c\uddea"
    const val KHR = "\ud83c\uddf0\ud83c\udded"
    const val KRW = "\ud83c\uddf0\ud83c\uddf7"
    const val KWD = "\ud83c\uddf0\ud83c\uddfc"
    const val LAK = "\ud83c\uddf1\ud83c\udde6"
    const val LKR = "\ud83c\uddf1\ud83c\uddf0"
    const val MMK = "\ud83c\uddf2\ud83c\uddf2"
    const val MYR = "\ud83c\uddf2\ud83c\uddfe"
    const val NOK = "\ud83c\uddf3\ud83c\uddf4"
    const val NPR = "\ud83c\uddf3\ud83c\uddf5"
    const val NZD = "\ud83c\uddf3\ud83c\uddff"
    const val PHP = "\ud83c\uddf5\ud83c\udded"
    const val PKR = "\ud83c\uddf5\ud83c\uddf0"
    const val RSD = "\ud83c\uddf7\ud83c\uddf8"
    const val RUB = "\ud83c\uddf7\ud83c\uddfa"
    const val SAR = "\ud83c\uddf8\ud83c\udde6"
    const val SEK = "\ud83c\uddf8\ud83c\uddea"
    const val SGD = "\ud83c\uddf8\ud83c\uddec"
    const val THB = "\ud83c\uddf9\ud83c\udded"
    const val USD = "\ud83c\uddfa\ud83c\uddf8"
    const val VND = "\ud83c\uddfb\ud83c\uddf3"
    const val ZAR = "\ud83c\uddff\ud83c\udde6"

    val list = listOf(
        AUD, BDT, BND, BRL, CAD, CHF, CNY, CZK, DKK, EGP, EUR, GBP, HKD, IDR, ILS, INR,
        JPY, KES, KHR, KRW, KWD, LAK, LKR, MMK, MYR, NOK, NPR, NZD, PHP, PKR, RSD, RUB, SAR, SEK,
        SGD, THB, USD, VND, ZAR
    )
}