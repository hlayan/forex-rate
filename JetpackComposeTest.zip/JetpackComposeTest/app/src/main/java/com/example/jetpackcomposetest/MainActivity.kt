package com.example.jetpackcomposetest

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.SmallTopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.jetpackcomposetest.ui.theme.JetpackComposeTestTheme
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            JetpackComposeTestTheme {
                Greeting()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Greeting() {
    val openDialog = remember { mutableStateOf(false) }

    val otherRate = remember { mutableStateOf("0") }
    val mmkRate = remember { mutableStateOf("0") }
    val currencyModel = remember { mutableStateOf(CurrencyModel()) }

    var actualCurrencyList by remember { mutableStateOf(Rates().currencyModelsList) }
    var title by remember { mutableStateOf("MMK Exchange") }

    val scaffoldState = rememberScaffoldState()
    val scope = rememberCoroutineScope() // in 1.0.0-beta `open()` and `close` are suspend functions
    val context = LocalContext.current
    val scrollBehavior = remember { TopAppBarDefaults.enterAlwaysScrollBehavior() }
    Scaffold(
        modifier = Modifier.nestedScroll(scrollBehavior.nestedScrollConnection),
        scaffoldState = scaffoldState,
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    actualCurrencyList = actualCurrencyList.sortedByDescending { it.currencyCode }
                }) {
                Icon(
                    imageVector = Icons.Filled.Favorite,
                    contentDescription = "Localized description",
                    tint = Color.White
                )
            }
        },
        floatingActionButtonPosition = FabPosition.Center,
        isFloatingActionButtonDocked = true,
        topBar = {
            SmallTopAppBar(
                title = {
                    Text(
                        text = title,
                        color = MaterialTheme.colors.primary,
                        fontSize = 20.sp
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = {
                            scope.launch { if (scaffoldState.drawerState.isClosed) scaffoldState.drawerState.open() else scaffoldState.drawerState.close() }
                        }, Modifier.padding(8.dp)
                    ) {
                        Icon(Icons.Filled.Menu, "menu")
                    }
                },
                actions = {
                    // RowScope here, so these icons will be placed horizontally
                    IconButton(onClick = {
                        title = Icons.Filled.ImportContacts.name
                        scope.launch {
                            scaffoldState.snackbarHostState.showSnackbar("Click")
                        }
                    }) {
                        Icon(
                            imageVector = Icons.Filled.ImportContacts,
                            contentDescription = "ImportContacts"
                        )
                    }
                    IconButton(
                        onClick = {
                            actualCurrencyList = actualCurrencyList.sortedBy { it.currencyCode }
                        }) {
                        Icon(
                            imageVector = Icons.Filled.Sort,
                            contentDescription = "Sort"
                        )
                    }
                },
                scrollBehavior = scrollBehavior
            )
        },
        bottomBar = {
            BottomAppBar(
                cutoutShape = RoundedCornerShape(50)
            ) {
                BottomNavigationItem(selected = true,
                    onClick = {
                        title = Icons.Filled.Facebook.name
                    },
                    icon = {
                        Icon(imageVector = Icons.Filled.Facebook, contentDescription = null)
                    },
                    label = {
                        Text(text = "Facebook")
                    })
                BottomNavigationItem(selected = false,
                    onClick = {
                        title = Icons.Filled.Approval.name
                    },
                    icon = {
                        Icon(imageVector = Icons.Filled.Approval, contentDescription = null)
                    }, label = {
                        Text(text = "Approval")
                    })
            }
        },
        drawerContent = {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(16.dp),
                modifier = Modifier.fillMaxHeight(),
                contentPadding = PaddingValues(16.dp)
            ) {
                items(20) {
                    OutlinedButton(
                        modifier = Modifier.fillMaxWidth(),
                        onClick = {
                            context.startActivity(Intent(context, ClockActivity::class.java))
                        }
                    ) {
                        Text(text = it.toString())
                    }
                }
            }
        },
        drawerGesturesEnabled = true,
        content = { paddingValues ->
            val contentDp = 16.dp
            val contentBottomDp = contentDp + paddingValues.calculateBottomPadding()
            Column {
                CurrencyConverter(currencyModel.value, otherRate, mmkRate)
                Divider()
                LazyColumn(
                    modifier = Modifier.fillMaxHeight(),
                    verticalArrangement = Arrangement.spacedBy(contentDp),
                    contentPadding = PaddingValues(contentDp, contentDp, contentDp, contentBottomDp)
                ) {
                    items(actualCurrencyList) {
                        CurrencyCard(it) {
                            title = it.currencyName
                            currencyModel.value = it
                            otherRate.value = "1"
                            mmkRate.value = currencyModel.value.exchangeRate
//                            openDialog.value = true

                            context.startActivity(
                                Intent(
                                    context,
                                    ConverterActivity::class.java
                                ).apply {
                                    putExtra("CurrencyModel", it)
                                })
                        }
                    }
                }
            }
            CalculateDialog(openDialog, currencyModel)
        }
    )
}

@Preview(showBackground = true)
@Composable
fun DefaultPreview() {
    JetpackComposeTestTheme {
        Greeting()
    }
}